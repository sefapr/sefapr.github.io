-- esta consulta requer a atualização da tabela PUBLICO.JBBINDER_VENDASD (ver passos anteriores)

select
   case
      when t1.CD_CNAE_ORIG in ('4511101') then 'Veículos novos'
      when t1.CD_CNAE_ORIG in ('4711301','4711302') then 'Hipermercados e supermercados'
      when t1.CD_CNAE_ORIG in ('4741500','4742300','4744001','4744003','4744099') then 'Materiais de construção e ferragens'
      when t1.CD_CNAE_ORIG in ('4751201','4752100') then 'Informática e telefonia'
      when t1.CD_CNAE_ORIG in ('4753900') then 'Áudio, vídeo e eletrodomésticos'
      when t1.CD_CNAE_ORIG in ('4754701') then 'Móveis'
      when t1.CD_CNAE_ORIG in ('4755503') then 'Cama/Mesa/Banho'
      when t1.CD_CNAE_ORIG in ('4771701') then 'Farmácias'
      when t1.CD_CNAE_ORIG in ('4772500') then 'Cosméticos, perfumes e higiene pessoal'
      when t1.CD_CNAE_ORIG in ('4781400') then 'Vestuário e acessórios'
      when t1.CD_CNAE_ORIG in ('4782201') then 'Calçados'
      when t1.CD_CNAE_ORIG in ('5611201','5611203') then 'Restaurantes e lanchonetes'
   end as Setor,
   DT_EMIS_DOC_FISC,
   sum(case when CD_SIST_ORIG = 1 then VL_TOTAL - VL_DESC else 0.00 end) valorNFe, sum(case when CD_SIST_ORIG = 5 then VL_TOTAL - VL_DESC else 0.00 end) valorNFC,
   sum(case
      when t1.CD_CNAE_ORIG in ('4511101') then case when CD_SIST_ORIG = 1 then VL_TOTAL - VL_DESC else 0.00 end
      when t1.CD_CNAE_ORIG in ('4711301','4711302') then case when CD_SIST_ORIG = 5 then VL_TOTAL - VL_DESC else 0.00 end
      when t1.CD_CNAE_ORIG in ('4741500','4742300','4744001','4744003','4744099') then VL_TOTAL - VL_DESC
      when t1.CD_CNAE_ORIG in ('4751201','4752100') then VL_TOTAL - VL_DESC
      when t1.CD_CNAE_ORIG in ('4753900') then VL_TOTAL - VL_DESC
      when t1.CD_CNAE_ORIG in ('4754701') then VL_TOTAL - VL_DESC
      when t1.CD_CNAE_ORIG in ('4755503') then VL_TOTAL - VL_DESC
      when t1.CD_CNAE_ORIG in ('4771701') then VL_TOTAL - VL_DESC
      when t1.CD_CNAE_ORIG in ('4772500') then VL_TOTAL - VL_DESC
      when t1.CD_CNAE_ORIG in ('4781400') then VL_TOTAL - VL_DESC
      when t1.CD_CNAE_ORIG in ('4782201') then VL_TOTAL - VL_DESC
      when t1.CD_CNAE_ORIG in ('5611201','5611203') then case when CD_SIST_ORIG = 5 then VL_TOTAL - VL_DESC else 0.00 end
   end) as ValorSetor
from PUBLICO.JBBINDER_VENDASD t1
where t1.CD_UF_EMIT = 41 and t1.CD_SIST_ORIG in (1,5) and grValor < 1000000 and MesmoCNPJ8 = 0 and Setor is not null
group by 1,2
order by 1,2
;
